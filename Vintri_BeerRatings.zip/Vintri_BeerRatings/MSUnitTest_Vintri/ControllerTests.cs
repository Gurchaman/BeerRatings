using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using Vintri_BeerRatings;
using Vintri_BeerRatings.Filters;
using Vintri_BeerRatings.Models;
using Vintri_Exercise.Controllers;

namespace MSUnitTest_Vintri
{
    [TestClass]
    public class ControllerTests
    {
        private IConfiguration _config;

        public ControllerTests()
        {
            IServiceCollection services = new ServiceCollection();

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddMemoryCache();
        }

        public IConfiguration Configuration
        {
            get
            {
                if (_config == null)
                {
                    var builder = new ConfigurationBuilder().AddJsonFile($"testsettings.json", optional: false);
                    _config = builder.Build();
                }

                return _config;
            }
        }


        /// <summary>
        /// Creates Beer Controller object
        /// </summary>
        /// <returns>BeerController Object</returns>
        private BeerController GetControllerDetails()
        {
            var services = new ServiceCollection();
            services.AddMemoryCache();
            var serviceProvider = services.BuildServiceProvider();
            var memoryCache = serviceProvider.GetService<IMemoryCache>();
            BeerController controller = new BeerController(_config, memoryCache);

            return controller;
        }


        /// <summary>
        /// Testing AddRatings method with InValid User Name
        /// </summary>
        [TestMethod]
        public void AddRatings_InValidUserName()
        {
            // Arrange
            BeerController controller = GetControllerDetails();
            UserRatingsModel userRatingsModel = new UserRatingsModel();
            userRatingsModel.userName = "John";              // In valid Email Id
            userRatingsModel.rating = 5;
            userRatingsModel.comments = "It is a nice beer";

            var context = GetCustomAttributeContext(userRatingsModel);
            var sut = new MyActionFilter();

            //Act
            sut.OnActionExecuting(context);

            // Assert
            Assert.AreEqual("400", ((Microsoft.AspNetCore.Mvc.ObjectResult)context.Result).StatusCode.ToString());
        }


        /// <summary>
        /// Testing AddRating method with InValid value of Beer Rating
        /// </summary>
        [TestMethod]
        public void AddRatings_InValidBeerRatings()
        {
            // Arrange
            int beerNumber = 1;
            BeerController controller = GetControllerDetails();
            UserRatingsModel userRatingsModel = new UserRatingsModel();
            userRatingsModel.userName = "John@gmail.com";
            userRatingsModel.rating = 7;                       // Rating here is out of the range of 1 and 5
            userRatingsModel.comments = "It is a nice beer";

            var sut = new MyActionFilter();

            //Act
            sut.OnActionExecuting(GetCustomAttributeContext(userRatingsModel));
            var result = controller.AddRatings(beerNumber, userRatingsModel);

            // Assert
            Assert.AreEqual(Messages.InValidRating, result.ToString());
        }


        /// <summary>
        /// Testing AddRating method with Invalid Beer ID
        /// </summary>
        [TestMethod]
        public void AddRatings_InValidBeerID()
        {
            // Arrange
            int beerNumber = 882277;           // This Beer id doesnot exist
            BeerController controller = GetControllerDetails();
            UserRatingsModel userRatingsModel = new UserRatingsModel();
            userRatingsModel.userName = "John@gmail.com";
            userRatingsModel.rating = 3;
            userRatingsModel.comments = "It is a nice beer";

            var sut = new MyActionFilter();

            //Act
            sut.OnActionExecuting(GetCustomAttributeContext(userRatingsModel));
            var result = controller.AddRatings(beerNumber, userRatingsModel);

            // Assert
            Assert.AreEqual(Messages.InValidBeerID, result.ToString());
        }


        /// <summary>
        /// Testing AddRating method with all valid data
        /// </summary>
        [TestMethod]
        public void AddRatings_AllValidData()
        {
            // Arrange
            int beerNumber = 1;
            BeerController controller = GetControllerDetails();
            UserRatingsModel userRatingsModel = new UserRatingsModel();
            userRatingsModel.userName = "John@gmail.com";
            userRatingsModel.rating = 4;
            userRatingsModel.comments = "It is a nice beer";

            var sut = new MyActionFilter();

            //Act
            sut.OnActionExecuting(GetCustomAttributeContext(userRatingsModel));
            var result = controller.AddRatings(beerNumber, userRatingsModel);

            // Assert
            Assert.AreEqual(Messages.SuccessRating, result.ToString());
        }



        /// <summary>
        /// Method to set Custom Attributes 
        /// </summary>
        /// <param name="userRatingsModel">UserRatingModel which contains details of the user ratings</param>
        /// <returns>ActionExecutingContext object</returns>
        private ActionExecutingContext GetCustomAttributeContext(UserRatingsModel userRatingsModel)
        {
            var modelState = new ModelStateDictionary();
            IDictionary<string, object> actionArguments = new Dictionary<string, object>
            {
                [Constants.UserRatings] = userRatingsModel
            };

            var httpContext = new DefaultHttpContext();
            var context = new ActionExecutingContext(
                new ActionContext(
                    httpContext: httpContext,
                    routeData: new RouteData(),
                    actionDescriptor: new ActionDescriptor(),
                    modelState: modelState
                ),
                new List<IFilterMetadata>(),
                actionArguments,
                new Mock<Controller>().Object);

            return context;
        }
    }
}
