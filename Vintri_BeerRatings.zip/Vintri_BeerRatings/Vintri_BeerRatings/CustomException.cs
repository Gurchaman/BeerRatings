﻿using System;

namespace Vintri_BeerRatings
{
    public class CustomException : Exception
    {
        public CustomException(string message): base (message)
        {
        
        }
    }
}
