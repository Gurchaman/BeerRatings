﻿namespace Vintri_BeerRatings
{
    public static class Constants
    {
        public static string UserNameRegex = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
        public static int BeerLowestRating = 1;
        public static int BeerHighestRating = 5;
        public static string UserRatings = "userRatings";
    }
}
