﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Vintri_BeerRatings;
using Vintri_BeerRatings.Filters;
using Vintri_BeerRatings.Models;
using Vintri_BeerRatings.Services;

namespace Vintri_Exercise.Controllers
{
    [ApiController]
    [Route("API/")]
    public class BeerController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;
        IList<BeerDetailsModel> beerDetails = new List<BeerDetailsModel>();

        public BeerController(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _cache = memoryCache;
        }


        /// <summary>
        /// Method to search beer details
        /// </summary>
        /// <returns>Returns matching results in JSON format</returns>
        [HttpGet]
        [Route("Beer/GetBeerDetails")]
        public JsonResult GetBeerDetails(string beer)
        {
            List<SaveBeerRatingsModel> beerRatingsModel = new List<SaveBeerRatingsModel>();

            try
            {
                if (!string.IsNullOrEmpty(beer))
                {
                    beerDetails = GetAllBeerDetails(beer);

                    var filePath = _configuration.GetSection("JSON_DataBasePath").Value;
                    var jsonData = System.IO.File.ReadAllText(filePath);
                    if (!string.IsNullOrEmpty(jsonData))
                    {
                        beerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(jsonData);   // Get the saved data from JSON database

                        var beerData = from beers in beerDetails
                                       join ratings in beerRatingsModel
                                          on beers.id equals ratings.id
                                       select new
                                       {
                                           id = beers.id,
                                           name = beers.name,
                                           description = beers.description,
                                           userRatings = ratings.userRatings
                                       };

                        if (beerData != null && beerData.Count() > 0)
                            return new JsonResult(new { Messages = Messages.Success, Data = beerData });        // Return data with the required details.
                    }
                }

                return new JsonResult(new { Messages = Messages.InValidBeerName, Data = string.Empty });    // If no data found, return empty data with a message
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());                                         // In real world, would log this message in the system log file or the Log database.
                Console.WriteLine(ex.StackTrace.ToString());
                return new JsonResult(new { Messages = Messages.Error, Data = string.Empty });    // Sending Error, so that API consumer knows some error occured at API end.
            }
        }


        /// <summary>
        /// Adds Ratings for a Beer
        /// </summary>
        /// <param name="ID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings in the range of 1 and 5</param>
        /// <returns>Success/failure message</returns>
        [HttpPost]
        [Route("Beer/AddRatings/{ID}")]
        [MyActionFilter]
        public string AddRatings(int ID, [FromBody] UserRatingsModel userRatings)
        {
            string message = string.Empty;

            try
            {
                // Callings validations first
                message = Validations(ID, userRatings);       

                if (string.IsNullOrEmpty(message))                    // If there is no validation error, procced further saving the data.
                {
                    if (SaveToJSONDatabase(ID, userRatings))          // Saving to JSON Database
                        return Messages.SuccessRating;
                    else
                        return Messages.Error;
                }
                else
                {
                    return message;                                       // If any validation failed, please return the message
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());                 // In real world, would log this message in the system log file or database
                Console.WriteLine(ex.StackTrace.ToString());                                                 
                return Messages.Error;                                 
            }
        }

        /// <summary>
        /// Saves data to the JSON Database
        /// </summary>
        /// <param name="intID">ID of the Beer</param>
        /// <param name="objUserRatings">Ratings of the beer</param>
        /// <returns></returns>
        private bool SaveToJSONDatabase(int id, UserRatingsModel userRatings)
        {
            string data = string.Empty;
            bool isExistingBeer = false;
            bool isExistingBeerForUser = false;
            var filePath = _configuration.GetSection("JSON_DataBasePath").Value;
            List<SaveBeerRatingsModel> beerRatingsModel = new List<SaveBeerRatingsModel>();

            try
            {
                var jsonData = System.IO.File.ReadAllText(filePath);       // Reading data from JSON Database


                // If the file is empty
                if (string.IsNullOrEmpty(jsonData))                        // If no data is present, simply save it as we donot need to append it to any data at this stage
                {
                    beerRatingsModel.Insert(0, AddRatingsToABeer(id, userRatings));
                }
                else
                {
                    // If there is some data already present, then first get the existing data. Then push new data to it and then save the new JSON so formed in JSON Database.

                    beerRatingsModel = JsonSerializer.Deserialize<List<SaveBeerRatingsModel>>(jsonData);    // Deseralizing the current data

                    foreach (SaveBeerRatingsModel itemBeer in beerRatingsModel)
                    {
                        if (itemBeer.id.Equals(id))
                        {
                            isExistingBeer = true;                               // Means check if beer data already exists in the saved JSON

                            foreach (UserRatingsModel itemRating in itemBeer.userRatings)
                            {
                                if (itemRating.userName.Equals(userRatings.userName, StringComparison.OrdinalIgnoreCase))
                                {
                                    isExistingBeerForUser = true;
                                    itemRating.rating = userRatings.rating;   // If same user is sharing rating for same beer again, then just 'Replace' the rating value
                                    itemRating.comments = userRatings.comments;
                                }
                            }

                            if (!isExistingBeerForUser)
                                itemBeer.userRatings.Add(userRatings);         // If a user is sharing the rating for the first time for a particular beer, 'Add' it

                        }
                    }
                    if (!isExistingBeer)
                        beerRatingsModel.Insert(0, AddRatingsToABeer(id, userRatings));                // Once the data is prepared, insert it in the list
                }

                // For better presentation, save the data in an ordered list of IDs.
                if (beerRatingsModel != null && beerRatingsModel.Count > 1)
                    beerRatingsModel = beerRatingsModel.OrderBy(result => result.id).ToList();

                var options = new JsonSerializerOptions { WriteIndented = true };                         //  For good indentation
                data = JsonSerializer.Serialize(beerRatingsModel, options);

                System.IO.File.WriteAllText(_configuration.GetSection("JSON_DataBasePath").Value, data);  // Saving the JSON
                
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());    // In real world, would log this message in the system log file or the Log database
                throw;                                       // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }


        /// <summary>
        /// Method to prepare the ratings model
        /// </summary>
        /// <param name="intID">ID of the Beer</param>
        /// <param name="objUserRatings">Rating of the beer</param>
        /// <returns>Ratings data in the form of model</returns>
        private SaveBeerRatingsModel AddRatingsToABeer(int id, UserRatingsModel userRatings)
        {
            SaveBeerRatingsModel beerRatingsModel = new SaveBeerRatingsModel();

            beerRatingsModel.id = id;
            beerRatingsModel.userRatings = new List<UserRatingsModel>();
            beerRatingsModel.userRatings.Add(userRatings);

            return beerRatingsModel;
        }


        /// <summary>
        /// Validates the Rating data
        /// </summary>
        /// <param name="intID">ID of the beer</param>
        /// <param name="objUserRatings">Ratings given to the beer</param>
        /// <returns>Error message of there is any error, else empty string</returns>
        private string Validations(int id, UserRatingsModel userRatings)
        {
            ExternalAPIs externalAPIs = new ExternalAPIs(_configuration, _cache);
            beerDetails = Task.Run(() => externalAPIs.GetBeerDetailsFromPunkAPIByID(id)).Result;           // API Call

            // Ensure the id parameter is a valid beer id
            if (beerDetails == null || beerDetails.Count < 1)
                return Messages.InValidBeerID;

            // Ensure that the rating is a valid value in the range of 1 to 5 
            if (!(userRatings.rating >= Constants.BeerLowestRating && userRatings.rating <= Constants.BeerHighestRating))
                return Messages.InValidRating;

            return string.Empty;                             // If validations goes fine, return an empty string 
        }


        /// <summary>
        /// Calls the Beer Punk API method
        /// </summary>
        /// <returns>Returns details of all the beers</returns>
        private IList<BeerDetailsModel> GetAllBeerDetails(string beerName)
        {
            try
            {
                ExternalAPIs externalAPIs = new ExternalAPIs(_configuration, _cache);                                // Setting up the constructor

                beerDetails = Task.Run(() => externalAPIs.GetBeerDetailsFromPunkAPIByName(beerName)).Result;         // Calls API here

                return beerDetails;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());     // In real world, would log this message in the system log file or database
                throw;                                        // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }
    }
}

