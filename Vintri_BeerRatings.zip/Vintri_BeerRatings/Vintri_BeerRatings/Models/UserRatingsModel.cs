﻿using System.Collections.Generic;

namespace Vintri_BeerRatings.Models
{
    public class UserRatingsModel
    {
        public string userName { get; set; }
        public int rating { get; set; }
        public string comments { get; set; }
    }

    public class SaveBeerRatingsModel
    {
        public int id { get; set; }

        public IList<UserRatingsModel> userRatings { get; set; }
    }

    public class BeerRatingsModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }

        public IList<UserRatingsModel> userRatings { get; set; }
    }
}
