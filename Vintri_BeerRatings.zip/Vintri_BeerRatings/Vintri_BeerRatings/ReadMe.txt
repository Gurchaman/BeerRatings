﻿/*
One requirement assumption:
In the requirements, it was not mentioned what to do in a case where a user is coming again to share ratings for the same beer again.
So as an assumption, I am replacing the beer ratings in such cases. I won't add a new rating value to the same beer for the same user.

1. Project is built using .NET Core 3.1 in Visual Studio 2022.

2. I have tried building the project using good solution architecture. Like creating separate folders for services, Filters, Models, Controllers, Database etc.
   I have used separate files for keeping constants and Display Messages.
   Some configurations are done in AppSettings.json file,
   Placed API links in appsettings.Development.JSON. 
   Reason being, if someone wants to replace the API links in future or on any higher environment, then it can be easily done via Appsettings.JSON file.

3. I have tried demonstrating the use of Memory Caching in ExternalAPIs service. Expiration time of the caching is configurable in appSettings.json

4. Demonstrated dependency injection of memory caching in controllers and services.

5. Unit tests are working great.

6. Tried putting some useful comments wherever necessary. Have given Method summary to all the methods.

7. I didn't handle the exceptions in all the methods. I handled them only in the main API methods. 
   Reason being - if any exception occurs anywhere in the flow, they would get caught in the main API methods for sure. I will have full stack trace in the exception details.

8. All the non API methods in the controller are set as private.

9. For testing, I used Postman and swagger both. Swagger is embedded in the startup.cs file.
*/